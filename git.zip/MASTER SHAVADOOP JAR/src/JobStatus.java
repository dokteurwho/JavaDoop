
public enum JobStatus {
    NOT_STARTED, STARTED, FINISHED 
}
